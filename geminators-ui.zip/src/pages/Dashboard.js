import React from "react";

function Dashboard() {
  return (
    <div className="page">
      <h2>📊 Test Dashboard (Mock)</h2>
      <div className="card-grid">
        <div className="card metric">Requirements: 12</div>
        <div className="card metric">Test Cases: 36</div>
        <div className="card metric pass">Passed: 30</div>
        <div className="card metric fail">Failed: 6</div>
      </div>

      <h3>Latest Test Cases</h3>
      <div className="card-grid">
        <div className="card">
          <h4>TC-LOG-01</h4>
          <p>Verify insulin delivery logs</p>
          <span className="badge pass">PASS</span>
        </div>
        <div className="card">
          <h4>TC-ECG-02</h4>
          <p>Check ECG signal capture</p>
          <span className="badge fail">FAIL</span>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;