import React, { useState } from "react";

const BASE_URL = "http://127.0.0.1:8080"; // your FastAPI backend

function Chatbot() {
  const [messages, setMessages] = useState([
    { sender: "bot", text: "Hi, I’m MedAI Assistant 👩‍⚕️. How can I help?" },
  ]);
  const [input, setInput] = useState("");
  const [pipelineState, setPipelineState] = useState(null);

  const sendMessage = async () => {
    if (!input.trim()) return;
    const newMsg = { sender: "user", text: input };
    setMessages((msgs) => [...msgs, newMsg]);
    setInput("");

    try {
      const res = await fetch(`${BASE_URL}/manager`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: input }),
      });
      const data = await res.json();
      console.log("Manager response:", data);

      if (data.answer) {
        setMessages((msgs) => [...msgs, { sender: "bot", text: data.answer }]);
      }

      if (data.status) {
        setPipelineState(data);
      }
    } catch (err) {
      console.error(err);
      setMessages((msgs) => [
        ...msgs,
        { sender: "bot", text: "⚠️ Error calling backend." },
      ]);
    }
  };

  const continuePipeline = async (userAction = "continue") => {
    if (!pipelineState || !pipelineState.stage) return;

    try {
      const payload = {
        stage: pipelineState.stage,
        req_id: pipelineState.req_id,
        user_action: userAction,
      };

      if (pipelineState.test_case_ids) {
        payload.test_case_ids = pipelineState.test_case_ids;
      }

      const res = await fetch(`${BASE_URL}/pipeline/continue`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      console.log("Pipeline response:", data);

      setPipelineState(data);
      if (data.status === "STOPPED" || data.status === "COMPLETE") {
        setMessages((msgs) => [
          ...msgs,
          { sender: "bot", text: data.message || "Pipeline finished." },
        ]);
        setPipelineState(null);
      }
    } catch (err) {
      console.error(err);
      setMessages((msgs) => [
        ...msgs,
        { sender: "bot", text: "⚠️ Pipeline error." },
      ]);
    }
  };

  return (
    <div className="page chatbot">
      <div className="chat-window">
        {messages.map((msg, i) => (
          <div key={i} className={`chat-message ${msg.sender}`}>
            {msg.text}
          </div>
        ))}
      </div>

      <div className="chat-input">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type your requirement or question..."
        />
        <button onClick={sendMessage}>Send</button>
      </div>

      {pipelineState && (
        <div className="stage-cards">
          <h3>📋 Current Stage: {pipelineState.stage}</h3>

          {pipelineState.requirement && (
            <div className="card">
              <h4>Requirement</h4>
              <p>{pipelineState.requirement.requirement_text}</p>
            </div>
          )}

          {pipelineState.testcases && (
            <div className="card">
              <h4>Test Cases</h4>
              {pipelineState.testcases.map((tc, idx) => (
                <div key={idx} className="testcase">
                  <strong>{tc.test_case_id}</strong> - {tc.title}
                  <p>{tc.description}</p>
                  <ul>
                    {tc.steps.map((s, i) => (
                      <li key={i}>{s}</li>
                    ))}
                  </ul>
                  <p><b>Expected:</b> {tc.expected_results.join(", ")}</p>
                </div>
              ))}
            </div>
          )}

          {pipelineState.iso_validation && (
            <div className="card">
              <h4>ISO Validation</h4>
              {pipelineState.iso_validation.map((iso, idx) => (
                <div key={idx}>
                  <p><strong>{iso.test_case_id}</strong> → {iso.compliant ? "✅ Compliant" : "❌ Issues"}</p>
                  {iso.missing_elements.length > 0 && <p>Missing: {iso.missing_elements.join(", ")}</p>}
                  <p>Suggestions: {iso.suggestions}</p>
                </div>
              ))}
            </div>
          )}

          {pipelineState.samples && (
            <div className="card">
              <h4>Samples</h4>
              {pipelineState.samples.map((s, i) => (
                <p key={i}>{s.test_case_id}: <a href={s.sample_path}>Sample JSON</a></p>
              ))}
            </div>
          )}

          {pipelineState.junit && (
            <div className="card">
              <h4>JUnit</h4>
              {pipelineState.junit.map((j, i) => (
                <p key={i}>{j.test_case_id}: <a href={j.junit_path}>JUnit File</a></p>
              ))}
            </div>
          )}

          {pipelineState.test_results && (
            <div className="card">
              <h4>Test Results</h4>
              {pipelineState.test_results.results.map((r, i) => (
                <p key={i}>{r.test_case_id}: <span className={r.status === "PASS" ? "badge pass" : "badge fail"}>{r.status}</span></p>
              ))}
            </div>
          )}

          {pipelineState.jira && (
            <div className="card">
              <h4>Jira Issue</h4>
              <a href={pipelineState.jira.url} target="_blank" rel="noreferrer">{pipelineState.jira.issue_key}</a>
            </div>
          )}

          <div className="actions">
            <button onClick={() => continuePipeline("continue")}>✅ Continue</button>
            <button onClick={() => continuePipeline("stop")}>❌ Stop</button>
          </div>
        </div>
      )}
    </div>
  );
}

export default Chatbot;