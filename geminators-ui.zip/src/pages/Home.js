import React from "react";
import { useNavigate } from "react-router-dom";

const instruments = [
  { name: "Insulin Pump", desc: "Smart insulin delivery system" },
  { name: "ECG Machine", desc: "Heart monitoring device" },
  { name: "Ventilator", desc: "Critical care breathing support" },
  { name: "MRI Scanner", desc: "Magnetic resonance imaging" },
];

function Home() {
  const navigate = useNavigate();

  return (
    <div className="page">
      <h2>Select a Device to Test</h2>
      <div className="card-grid">
        {instruments.map((inst, i) => (
          <div key={i} className="card" onClick={() => navigate("/chatbot")}>
            <h3>{inst.name}</h3>
            <p>{inst.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Home;